var app = angular.module("Store_ABC",["ngRoute"]);
			app.config(function($routeProvider){
					$routeProvider
					.when('/',{
						templateUrl : 'views/storeView.html',
						controller :  'storeViewCtrl'
					})
					.when('/cart',{
						templateUrl : 'views/viewCart.html',
						controller : 'viewCartCtrl'
					})
					.otherwise({
						redirectTo: '/'
					})
				});
			app.service('productService', function() {
				  var cartList = [];

				  var addProduct = function(newObj) {
				      cartList.push(newObj);
				  };

				  var getProducts = function(){
				      return cartList;
				  };

				  return {
				    addProduct: addProduct,
				    getProducts: getProducts
				  };

				});
				app.controller('storeViewCtrl',function($scope,$http,productService){
					$http.get('./js/products.json').success(function(data){
						$scope.products = data;
					});
					$scope.cartList = [];
					$scope.addToCart = function(product){
						console.log(product);
						this.isDisabled = true;
						productService.addProduct(product);
					};
					});
					app.controller('viewCartCtrl',function($scope,$http,productService){
					$scope.productsInCart = productService.getProducts();
					$scope.count = 1;
					var qty = 1;
					$scope.increment = function(){
						this.count+=1;
						qty = this.count;
					};
					$scope.decrement = function(){
						this.count-=1;
						qty = this.count;
					};
					$scope.getTotal = function(){
						var total = 0;
						for(var i=0;i< $scope.productsInCart.length;i++){
							var product = $scope.productsInCart[i];
							total = total + (product.productPrice * qty);
						}
						return total;
					}
					$scope.removeProduct = function(index){
						$scope.productsInCart.splice(index, 1);
					}
				   });
			