var app = angular.module("Store_ABC",["ngRoute"]);
			app.config(function($routeProvider){
					$routeProvider
					.when('/',{
						templateUrl : storeView.html,
						controller : storeViewCtrl
					})
					.when('/cart',{
						templateUrl : viewCart.html,
						controller : viewCartCtrl
					})
				})
				app.controller('storeViewCtrl',function($scope,$http){
					$http.get('products.json').success(function(data){
						$scope.products = data;
					})
				})